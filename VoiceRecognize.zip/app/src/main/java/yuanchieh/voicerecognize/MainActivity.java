package yuanchieh.voicerecognize;

//reference :
//1.http://www.dotblogs.com.tw/superlm102/archive/2013/02/05/90118.aspx
//2.http://stackoverflow.com/questions/2620444/how-to-prevent-a-dialog-from-closing-when-a-button-is-clicked

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;


public class MainActivity extends Activity {

    private Button btnVoice;
    private Dialog dialog;
    private static final int S2T_RESULT_CODE = 1116;
    private static final String TAG = "Speech2TextActivity";
    private Button btnStart,btnDone;
    private TextView txtInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnVoice = (Button)findViewById(R.id.btn_voice);
        btnVoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.show();
            }
        });

        //custom dialog
        dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.dialog);
        txtInput = (TextView)dialog.findViewById(R.id.txt_input);
        Window dialogWindow = dialog.getWindow();
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
        lp.width = 800; // 寬度
        lp.height = 800; // 高度
        lp.alpha = 1.0f; // 透明度
        btnStart = (Button) dialog.findViewById(R.id.btn_start);
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"en-US");
                intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Plz Speak");

                MainActivity.this.startActivityForResult(intent, S2T_RESULT_CODE);
            }
        });
        btnDone = (Button) dialog.findViewById(R.id.btn_done);
        btnDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, txtInput.getText(), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });
        btnDone.setEnabled(false);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != S2T_RESULT_CODE) {
            Log.d(TAG, "The request code doesn't match - " + requestCode);
            return;
        }
        if (resultCode != RESULT_OK) {
            Log.d(TAG, "The result code doesn't match - " + resultCode);
            return;
        }
        // 語音辨識成功後，將結果回寫
        // only retrieve one result
        List<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        txtInput.setText(result.get(0).toString());
        btnDone.setEnabled(true);
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
